@include('layouts/header')



<section class="inner-sec upgradesubscription">
    <div class="container"> 
     <div class="row">
         <div class="col-md-12">
             <!-- Display error messages -->
                @if(session('error'))
                    <div class="alert alert-danger text-center">
                        {{ session('error') }}
                    </div>
                @endif
                <!-- Display success message -->
                @if(session('success'))
                    <div class="alert alert-success text-center">
                        {{ session('success') }}
                    </div>
                @endif 

             </div>
         </div>
       <div class="row">
            <div class="col-md-12 text-center">
                <div class="cvform-heading">
                    <h2>Manage Subscription</h2>
                   @if($selectedPlan)
                    <H6>Selected Plan</h6>
                   @else
                   <H6>Other Plan</h6>
                   @endif
                </div>
            </div>                              
        </div>
        @if($selectedPlan)
        <div class="row">
           <div class="col-lg-4 col-md-6">
                <div class="generic_content">
                    <div class="generic_head_price">
                        <div class="generic_head_content">
                               <span>{{ isset($selectedPlan->plan->name) ? $selectedPlan->plan->name : '' }}</span>
                        </div>
                        <div class="generic_price_tag">
                                <span class="sign">$</span><span class="currency">{{ $selectedPlan->price_monthly }}</span><span class="month">/Mon</span>
                        </div>
                    </div>                            
                    <div class="generic_feature_list">
                        <ul>
                            <li><span>{{ isset($selectedPlan->plan->description) ? $selectedPlan->plan->description : '' }}</span></li>
                        </ul>
                    </div>
                    <div class="generic_price_btn">
                          <ul>
                             <li>
                            <a href="{{ route('mysubscriptions.upgrade') }}" class="btn btn-info"> Upgrade</a>
                              </li>
                                  <li>
                            <a  href="javascript:void(0);" id="cancel-btn" onclick="confirmCancellation('{{ route('mysubscriptions.cancel') }}')" class="btn btn-info btn-danger">Cancel</a>
                        </li>
                        </ul>
                    </div>
                </div>
            </div>            
           <div class="col-lg-8 col-md-6"> 
            <div class="transationhistory">
              <h2>Transation History</h2>
               <div class="table-responsive">
                 <table class="table table-bordered">
                    <tr>
                      <th>#</th>
                      <th>Plan name</th>
                      <th>Amount</th>
                      <th>Date</th>
                    </tr>
                    @if(count($transactions) > 0)
                    @foreach($transactions as $key=> $Transactions)
                    <tr>
                        <td>{{ $key + 1 }}</td>
                        <td>{{ $Transactions->plan ? $Transactions->plan->name : '' }}</td>
                        <td>$ {{ $Transactions->amount ?: 'N/A' }}</td>
                        <td>{{ $Transactions->date ?: '' }}</td>
                    </tr>                                        
                    @endforeach
                    @else
                    <tr>
                        <td colspan="4" style="text-align: center">No data found</td>
                    </tr>
                    @endif
                  </table>
              </div>
              </div>
           </div>
        </div>
        @else
        <div class="row">
            @foreach ($plans as $plan)
                <div class="col-lg-4 col-md-12">
                            <div class="generic_content">
                                <div class="generic_head_price">
                                    <div class="generic_head_content">
                                            <span>{{ $plan->name }}</span>
                                    </div>
                                    <div class="generic_price_tag">
                                            <span class="sign">$</span><span class="currency">{{ $plan->price_monthly }}</span><span class="month">/Mon</span>
                                    </div>
                                </div>                            
                                <div class="generic_feature_list">
                                    <ul>
                                        <li><span>{{ $plan->description }}</span></li>
                                    </ul>
                                </div>
                                <div class="generic_price_btn">
                                    <a href="{{ !empty($plan->slug) ? route('mysubscriptions.show', ['plan' => $plan->slug, 'subscriptionType' => 'month', 'url_to' => 'manage']) : route('mysubscriptions.show', ['plan' => 'default', 'subscriptionType' => 'month' , 'url_to' => 'manage']) }}" class="btn btn-info">Select</a>
                                </div>
                            </div>
                        </div>
            @endforeach
            <div class="col-md-12"> 
            <div class="transationhistory transationhistory-12">
              <h2>Transation History</h2>
               <div class="table-responsive">
                 <table class="table table-bordered">
                    <tr>
                      <th>#</th>
                      <th>Plan name</th>
                      <th>Amount</th>
                      <th>Date</th>
                    </tr>
                    @if(count($transactions) > 0)
                    @foreach($transactions as $key=> $Transactions)
                    <tr>
                        <td>{{ $key + 1 }}</td>
                        <td>{{ $Transactions->plan ? $Transactions->plan->name : '' }}</td>
                        <td>$ {{ $Transactions->amount ?: 'N/A' }}</td>
                        <td>{{ $Transactions->date ?: '' }}</td>
                    </tr>                                        
                    @endforeach
                    @else
                    <tr>
                        <td colspan="4" style="text-align: center">No data found</td>
                    </tr>
                    @endif
                  </table>
                  </div>
                  </div>
           </div>
        </div>
        @endif
    </div>
</section>
<script>
    function confirmCancellation(cancelUrl) {
        if (confirm("Are you sure you want to cancel your subscription?")) {
            window.location.href = cancelUrl;
        }
    }
</script> 
@include('layouts/footer')
